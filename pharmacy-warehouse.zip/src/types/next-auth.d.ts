import type { DefaultSession } from "next-auth";
import type { Role } from "@generated/prisma/client";
import "next-auth/jwt";

declare module "next-auth" {
    interface User {
        role: Role;
    }

    interface Session { 
        user: {
            id: string;
            role: Role;
        } & DefaultSession["user"];
    }
}

declare module "next-auth/jwt" {
    interface JWT {
        id: string;
        role: Role;
    }
}