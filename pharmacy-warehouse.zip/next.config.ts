import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Keep the dev tools button off the sidebar
  devIndicators: {
    position: "bottom-right",
  },
};

export default nextConfig;
